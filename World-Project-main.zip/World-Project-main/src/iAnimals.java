public interface iAnimals {
    //Getting
    void getAnimal();
    void getName();
    void getAge();
    void getWeight();

    //Returning
    String returnAnimal();
    String returnName();
    int returnAge();
    double returnWeight();

}
